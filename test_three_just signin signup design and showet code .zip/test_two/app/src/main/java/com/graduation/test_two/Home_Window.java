package com.graduation.test_two;

import android.content.Intent;
import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.navigation.ui.AppBarConfiguration;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.graduation.test_two.Model.Catagory;
import com.graduation.test_two.ViewHolder.ProductViewHolder;
import com.squareup.picasso.Picasso;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;
import io.paperdb.Paper;

import android.view.Menu;
import android.app.FragmentManager;

import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.TextView;


public class Home_Window extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener  {

    private AppBarConfiguration mAppBarConfiguration;
 private DatabaseReference productRef;
 private RecyclerView recyclerView_menu;
 RecyclerView.LayoutManager layoutManager;
 FirebaseRecyclerAdapter<Catagory, ProductViewHolder> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home__window);
        Toolbar toolbar = findViewById(R.id.toolbar);
        //toolbar.setTitle("Home");
        setSupportActionBar(toolbar);
        getSupportActionBar().hide();
        FloatingActionButton fab = findViewById(R.id.fab);/// add to cart



        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "added to Cart", Snackbar.LENGTH_LONG).setAction("Action", null).show();
            }
        });

        productRef = FirebaseDatabase.getInstance().getReference().child("Catagory");
        recyclerView_menu= findViewById(R.id.recycler_menu);
        recyclerView_menu.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView_menu .setLayoutManager( layoutManager);


        Paper.init(this);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
//        mAppBarConfiguration = new AppBarConfiguration.Builder(R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow, R.id.nav_tools, R.id.nav_share, R.id.nav_send).setDrawerLayout(drawer).build();
//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
//        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
//        NavigationUI.setupWithNavController(navigationView, navController);

    View headerView = navigationView.getHeaderView(0);
        TextView username= headerView.findViewById(R.id.username);
        CircleImageView profieimage= headerView.findViewById(R.id.profile_image);

        username.setText("Nadeem Abu Al Arayes ");
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerOptions<Catagory> options= new FirebaseRecyclerOptions.Builder<Catagory>()
        .setQuery(productRef,Catagory.class).build();

        adapter = new FirebaseRecyclerAdapter<Catagory, ProductViewHolder>(options) {

                    @Override
                    protected void onBindViewHolder(@NonNull final ProductViewHolder holder, final int pos, @NonNull Catagory catagory) {
                        final String menu_id = getRef(pos).getKey();

                        holder.foodtype.setText(catagory.getName());
                        Picasso.get().load(catagory.getImage()).into(holder.imageView);
                        final  Catagory clickItem = catagory;

                            holder.itemView.setOnClickListener(new View.OnClickListener() {


                                @Override
                                public void onClick(View v) {

                                    // get catagoryid and send to new activity
                                    Intent maindishlist = new Intent(Home_Window.this, Foodlist_one.class);

                                    // becuase catagoryid is key , so we just get key of this items
//                                  maindishlist.putExtra("CatagoryID",adapter.getRef(pos).getKey());
                                    maindishlist.putExtra("CatagoryID",menu_id);
                                    startActivity(maindishlist);
                                }
                            });


//                        if ( holder.foodtype.equals("Appetizer")  ) {
//                            holder.itemView.setOnClickListener(new View.OnClickListener() {
//                                @Override
//                                public void onClick(View v) {
//                                    // get catagoryid and send to new activity
//                                    Intent maindishlist = new Intent(Home_Window.this, signin.class);
//
//                                    // becuase catagoryid is key , so we just get key of this items
////                                  maindishlist.putExtra("CatagoryID",adapter.getRef(pos).getKey());
//                                    //maindishlist.putExtra("CatagoryID",menu_id);
//                                    startActivity(maindishlist);
//                                }
//                            });
//                        }

//                        holder.itemView.setItemClickListner(new ItemClickListner() {
//                            @Override
//                            public void onClick(View view, int position, boolean isLong) {
//                                // get catagoryid and srnd to new activity
//                                Intent maindishlist = new Intent(Home_Window.this,Foodlist_one.class);
//
//                                // becuase catagoryid is key , so we just get key of this items
//                             //   maindishlist.putExtra("CatagoryID",adapter.getRef(i).getKey());
//                                 startActivity(maindishlist);
//                            }
//                        });

                    }

                    @NonNull
                    @Override
                    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                       View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_items_layout,parent,false);
                          ProductViewHolder holder = new ProductViewHolder(view);
                        return  holder;

                    }



                };


recyclerView_menu.setAdapter(adapter);
adapter.startListening();


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home__window, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
//    @Override
//    public boolean onSupportNavigateUp() {
//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
//        return NavigationUI.navigateUp(navController, mAppBarConfiguration) || super.onSupportNavigateUp();
//    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        FragmentManager fragmentManager = getFragmentManager();

//        if (id == R.id.nav_first_layout) {
//            fragmentManager.beginTransaction()
//                    .replace(R.id.content_frame
//                            , new FirstFragment())
//                    .commit();
//        } else if (id == R.id.nav_second_layout) {
//            fragmentManager.beginTransaction()
//                    .replace(R.id.content_frame
//                            , new SecondFragment())
//                    .commit();
//        } else if (id == R.id.nav_third_layout) {
//            fragmentManager.beginTransaction()
//                    .replace(R.id.content_frame
//                            , new ThirdFragment())
//                    .commit();
//        }//
//

        if (id == R.id.nav_Order) {

        }
        else if (id == R.id.nav_Favorite) {

        }
        else if (id == R.id.nav_coupons) {

        }
        else if (id == R.id.nav_payment) {

        }
        else if (id == R.id.nav_LogOut) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}
