package com.graduation.test_two.Model;

public class customer {

    public  String name,email,password,confrimpassword,phone;

    public customer(){

    }

    public customer(String name, String email, String password, String confrimpassword,String phone) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.confrimpassword = confrimpassword;
        this.phone = phone;
    }
}
