package com.graduation.test_two.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.graduation.test_two.Interface.ItemClickListner;
import com.graduation.test_two.R;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView foodtype;
    public ImageView imageView;
    public ItemClickListner listner;


    public ProductViewHolder(@NonNull View itemView) {
        super(itemView);


        imageView = (ImageView)itemView.findViewById(R.id.imagedes);
        foodtype = (TextView) itemView.findViewById(R.id.nameoffood);
    }

    public void setItemClickListner(ItemClickListner Listner)
    {

        this.listner= listner;
    }


    @Override
    public void onClick(View v) {
listner.onClick(v,getAdapterPosition(),false);
    }
}
